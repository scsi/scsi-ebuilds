/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: sident.h,v 1.4.4.1 1999/02/03 22:35:45 steve Exp $
 */

#ifndef SIDENT_H
#define SIDENT_H

#ifndef IDTENTRY_SIZE
#define IDTENTRY_SIZE 1024
#endif

extern void InitIdentEntry   P((char *));
extern int  IdentQuery       P((S5IOHandle, char *));
extern void MakeIdentEntry   P((S5IOHandle, S5IOHandle, S5LinkInfo *, char *));
extern void RemoveIdentEntry P((char *));

#endif
