/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: validate.h,v 1.12.4.2 1999/02/03 22:35:57 steve Exp $
 */

/* This file contains all the prototypes for validation and configuration    */
/* file information...                                                       */
#ifndef VALIDATE_H
#define VALIDATE_H

#include "confutil.h" 

extern void  ReadConfig  P((void)); /* (Re)read and parse the config file   */
extern int   Authorize   P((S5LinkInfo *, int));
extern int   GetAuths    P((S5LinkInfo *, list **));
extern int   GetRoute    P((const S5NetAddr *, const char *, char *, S5NetAddr *));
extern int   GetProxy    P((const S5NetAddr *, const char *, char *, S5NetAddr *, int *, u_char *));
extern int   GetFilter   P((S5LinkInfo *, char *));

#endif
