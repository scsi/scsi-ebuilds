/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: info.h,v 1.11.4.2 1999/02/03 22:35:36 steve Exp $
 */

#ifndef INFO_H
#define INFO_H

extern void GetName      P((char *, S5NetAddr *));
extern void GetServ      P((char *, u_short, char *));
extern int  ResolveNames P((S5LinkInfo *));

#endif
