/* Define if you have setuptem                                               */
#undef HAVE_SETUPTERM

/* Define if you have a sys_errlist                                          */
#undef HAVE_SYSERRLIST

/* Define if you have getcwd but no getwd                                    */
#undef GETCWD

/* Define this to be the configuration file you want...                      */
#define LIBCONF_FILE "/etc/libsocks5.conf"

/* Define this to be the configuration file you want...                      */
#define SRVCONF_FILE "/etc/socks5.conf"

/* Define this to be the configuration file you want...                      */
#define SRVIDT_FILE  "/tmp/socks5.ident"

/* Define this to be the configuration file you want...                      */
#define SRVPID_FILE  "/tmp/socks5.pid"

/* Define this to be the socks5 passwd file you want...                      */
#define SRVPWD_FILE  "/etc/socks5.passwd"

/* define this to be the default socks server you want to use                */
#define SOCKS_DEFAULT_SERVER "127.0.0.1"

/* define this to be the default socks version you want to use               */
#undef SOCKS_DEFAULT_VERSION

/* define this to be the default socks port you want to use                  */
#define SOCKS_DEFAULT_PORT 1080

/* what syslog level do you want messages to be logged at...?                */
#undef SYSLOG_FAC

/* define this if you don't have cc_t in sys/termios.h                       */
#undef NO_CC_T

/* define this to the path of your traceroute...                             */
#undef TROUTEPROG

/* define this to the path of your ping                                      */
#undef PINGPROG

/* define this to whatever is you can set within a signal handler.           */
#undef sig_atomic_t

/* define this if you have IPPORT_RESERVED somewhere...usually netinet/in.h  */
#undef HAVE_IPPORT_RESERVED

/* define this to your libc, if it has a version number (/lib/libc.so.1.9)   */
#undef LIBC_NAME
#undef LIBDGC_NAME
#undef LIBNSL_NAME
#undef LIBRESOLV_NAME
#undef LIBSOCKET_NAME

/* define if you want to use threading (if available)                        */
#undef USE_THREADS

/* define if you want to use /etc/passwd for user/pass authentication        */
#undef USE_PASSWD

/* Define if struct sockaddr_un contains sun_len.                            */
#undef HAVE_SOCKADDR_SUN_LEN

/* Define if the compiler can handle function prototyping                    */
#undef HAVE_FUNC_PROTOTYPE
