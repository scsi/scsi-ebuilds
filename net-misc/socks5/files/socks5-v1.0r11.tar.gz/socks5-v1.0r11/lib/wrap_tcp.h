/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: wrap_tcp.h,v 1.8.2.1.2.2 1999/02/03 22:35:27 steve Exp $
 */

#ifndef WRAP_TCP_H
#define WRAP_TCP_H

int lsTcpBind        P((S5IOHandle, CONST ss *, int));
int lsTcpConnect     P((S5IOHandle, CONST ss *, int));
int lsTcpGetsockname P((S5IOHandle,       ss *, int *));
int lsTcpGetpeername P((S5IOHandle,       ss *, int *));

IORETTYPE lsTcpSend     P((S5IOHandle, const IOPTRTYPE, IOLENTYPE, int));
IORETTYPE lsTcpRecv     P((S5IOHandle,       IOPTRTYPE, IOLENTYPE, int));
IORETTYPE lsTcpRecvfrom P((S5IOHandle,       IOPTRTYPE, IOLENTYPE, int, const ss *, int *));
IORETTYPE lsTcpRecvmsg P((S5IOHandle, ms *, int));
IORETTYPE lsTcpSendmsg P((S5IOHandle, ms *, int));
#endif
