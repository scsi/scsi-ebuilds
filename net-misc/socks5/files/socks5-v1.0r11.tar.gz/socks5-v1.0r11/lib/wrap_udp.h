/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: wrap_udp.h,v 1.8.4.2 1999/02/03 22:35:29 steve Exp $
 */

#ifndef UDP_WRAPPER_H
#define UDP_WRAPPER_H

int lsUdpBind         P((S5IOHandle, CONST ss *, int));
int lsUdpConnect      P((S5IOHandle, CONST ss *, int));
int lsUdpGetpeername  P((S5IOHandle,       ss *, int *));
int lsUdpGetsockname  P((S5IOHandle,       ss *, int *));

IORETTYPE lsUdpSend         P((S5IOHandle, const IOPTRTYPE, IOLENTYPE, int));
IORETTYPE lsUdpSendto       P((S5IOHandle, const IOPTRTYPE, IOLENTYPE, int, const ss *, int));
IORETTYPE lsUdpRecvfrom     P((S5IOHandle,       IOPTRTYPE, IOLENTYPE, int, const ss *, int *, int));
IORETTYPE lsUdpSendmsg         P((S5IOHandle, const ms *, int));
IORETTYPE lsUdpRecvmsg         P((S5IOHandle, const ms *, int));
#endif
