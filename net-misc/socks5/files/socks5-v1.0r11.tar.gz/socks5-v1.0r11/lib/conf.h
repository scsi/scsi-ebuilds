/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: conf.h,v 1.8.4.1 1999/02/03 22:35:04 steve Exp $
 */

#ifndef __CONF_H__
#define __CONF_H__

extern u_char lsHowToConnect P((const S5NetAddr *, u_char, S5NetAddr **, int *, char *, S5NetAddr *));

#endif
