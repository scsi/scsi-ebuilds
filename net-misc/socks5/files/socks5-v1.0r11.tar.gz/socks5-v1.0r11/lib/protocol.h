/* Copyright (c) 1995-1999 NEC USA, Inc.  All rights reserved.               */
/*                                                                           */
/* The redistribution, use and modification in source or binary forms of     */
/* this software is subject to the conditions set forth in the copyright     */
/* document ("Copyright") included with this distribution.                   */

/*
 * $Id: protocol.h,v 1.19.4.1 1999/02/03 22:35:19 steve Exp $
 */

#ifndef __PROTOCOL_H_
#define __PROTOCOL_H_

extern char *lsEffUser               P((void));
extern int LIBPREFIX2(init)          P((const char *));

extern int lsSetProtoAddr            P((u_char,       char *, const S5NetAddr *));
extern int lsGetProtoAddr            P((u_char, const char *,       S5NetAddr *));
extern int lsGetProtoAddrLenFromAddr P((u_char, const S5NetAddr *));
extern int lsGetProtoAddrLenFromBuf  P((u_char, const char *));

extern int lsProtoExchg   P((S5IOHandle, S5IOInfo *, const S5NetAddr *, char *, u_char, u_char, u_char));
extern int lsSendRequest  P((S5IOHandle, S5IOInfo *, const S5NetAddr *, u_char, u_char, u_char, char *));
extern int lsReadRequest  P((S5IOHandle, S5IOInfo *, S5NetAddr *, u_char *, u_char *, u_char *));
extern int lsSendResponse P((S5IOHandle, S5IOInfo *, const S5NetAddr *, u_char, u_char, u_char, char *));
extern int lsReadResponse P((S5IOHandle, S5IOInfo *, S5NetAddr *, u_char, u_char *, u_char *));

#endif /* __PROTOCOL_H_ */

