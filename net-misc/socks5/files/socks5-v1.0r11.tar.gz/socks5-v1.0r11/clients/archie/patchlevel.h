/*
 * Archie Client version 1.4.1.
 *
 * History:
 *
 * 10/26/92 v1.4.1	Further fixes, avoid alloca.
 * 10/20/92 v1.4	Added PCNFS support, ported to Solaris 2, print domains
 *			using reverse-sort, added archie.el to distribution,
 *			added Alex mode, -V option, use getopt.
 * 04/14/92 v1.3.2	Further porting, add ARCHIE_HOST env var, new version
 *			of make.com (VMS), support for SVR4, merged 4.2E
 *			Prospero changes, CUTCP stack fix.
 * 01/10/92 v1.3.1	Bug.
 * 01/09/92 v1.3	CUTCP (DOS) support, more VMS support (UCX), added
 *			option -L to list hosts & default server.
 * 11/20/91 v1.2	VMS support (Wallongong and Multinet),
 *			DOS and OS/2 support, new regex.c from oz, added
 *			udp.c and the testing info for UDP blockage, cope
 *			with GCC 1.x's bad sparc structure handling, and
 *			total rewrite of dirsend.c to be more modular (more
 *			usable by xarchie).
 * 08/20/91 v1.1	Major revisions and hacks of the Prospero code.
 * 07/31/91 v1.0	Original.
 */
